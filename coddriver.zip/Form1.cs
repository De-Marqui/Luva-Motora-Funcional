using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using SharpDX.DirectInput;
using System.Security.Cryptography.X509Certificates;
using System.Drawing.Text;
using System.Security.Cryptography;
using System.Diagnostics;
using WindowsInput;
using WindowsInput.Native;

namespace ProjetoInterface
{
    public partial class Form1 : Form
    {
        [DllImport("User32.dll")]
        static extern IntPtr SetForegroundWindow(IntPtr point);

        private Joystick controle;
        private bool joystickReady = false;

        public Form1()
        {
            InitializeComponent();
            if (joystickReady == true)
            {
                MessageBox.Show("Estou entrando nessa condi��o");
                Thread thread = new Thread(new ThreadStart(joystickOperate));
                thread.Start();
            }
        }

        private void click_conectarControle(object sender, EventArgs e)
        {
            var directInput = new DirectInput();
            var joystickGUID = Guid.Empty;

            foreach (var deviceInstance in directInput.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AllDevices))
            {
                joystickGUID = deviceInstance.InstanceGuid;
            }

            if(joystickGUID == Guid.Empty)
            {
                foreach (var deviceInstance in directInput.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AllDevices))
                {
                    joystickGUID = deviceInstance.InstanceGuid;
                }
                if(joystickGUID == Guid.Empty)
                {
                    MessageBox.Show("Controle n�o foi encontrado","Aviso");
                    return;
                }
            }
            naoConectou.Visible = false;
            conectouControle.Visible = true;
            var joystick = new Joystick(directInput, joystickGUID);
            joystick.Properties.BufferSize = 128;
            joystick.Acquire();
            MessageBox.Show("Controle conectado!", "Aviso");
            Thread thread = new Thread(() => testa_controle(joystick));
            thread.Start();
            controle = joystick;
            if(joystickReady = true)
            {
                //Thread joyOp = new Thread(new ThreadStart(joystickOperate));
                //joyOp.Start();
                joystickOperate();
            }
        }

        private void testa_controle(Joystick joystick)
        {
            //Sess�o que vai criar uma thread para testar os bot�es, mais adiante do projeto, ter� um bot�o s� pra isso
            Brush cor_azul = new SolidBrush(Color.Blue);
            Brush cor_verde = new SolidBrush(Color.Green);
            Brush cor_amarela = new SolidBrush(Color.Yellow);
            Brush cor_vermelha = new SolidBrush(Color.Red);
            Brush cor_laranja = new SolidBrush(Color.Orange);
            Pen cor_preto = new Pen(Color.Black);
            Rectangle quadrado1 = new Rectangle(50, 200, 100, 100);
            Rectangle quadrado2 = new Rectangle(150, 200, 100, 100);
            Rectangle quadrado3 = new Rectangle(250, 200, 100, 100);
            Rectangle quadrado4 = new Rectangle(350, 200, 100, 100);
            Rectangle quadrado5 = new Rectangle(450, 200, 100, 100);
            var botaoVerde = false;
            var botaoVermelho = false;
            var botaoAmarelo = false;
            var botaoAzul = false;
            var botaoLaranja = false;
            Graphics quadradosTesteControle = canvas.CreateGraphics();
            quadradosTesteControle.DrawRectangle(cor_preto, quadrado1);
            quadradosTesteControle.DrawRectangle(cor_preto, quadrado2);
            quadradosTesteControle.DrawRectangle(cor_preto, quadrado3);
            quadradosTesteControle.DrawRectangle(cor_preto, quadrado4);
            quadradosTesteControle.DrawRectangle(cor_preto, quadrado5);

            if (canvas.InvokeRequired)
            {
                Action testa_controle_seguro = delegate { testa_controle(joystick);};
                canvas.Invoke(testa_controle_seguro);

            }
            else
            {
                while (true)
                {
                    if (botaoAmarelo && botaoAzul && botaoVerde && botaoVermelho && botaoLaranja)
                    {
                        quadradosTesteControle.Clear(BackColor);
                        Thread.Sleep(500);
                        MessageBox.Show("Bot�es testados com sucesso!", "Alerta");
                        joystickReady = true;
                        break;
                    }
                    joystick.Poll();
                    var data = joystick.GetBufferedData();
                    foreach (var state in data)
                    {
                        if(state.Offset.ToString().Contains("Buttons0"))
                        {
                            quadradosTesteControle.FillRectangle(cor_verde, quadrado1);
                            botaoVerde = true;
                        }
                        if (state.Offset.ToString().Contains("Buttons1"))
                        {
                            quadradosTesteControle.FillRectangle(cor_vermelha, quadrado2);
                            botaoVermelho = true;
                        }
                        if (state.Offset.ToString().Contains("Buttons2"))
                        {
                            quadradosTesteControle.FillRectangle(cor_amarela, quadrado3);
                            botaoAmarelo = true;
                        }
                        if (state.Offset.ToString().Contains("Buttons3"))
                        {
                            quadradosTesteControle.FillRectangle(cor_azul, quadrado4);
                            botaoAzul = true;
                        }
                        if (state.Offset.ToString().Contains("Buttons5"))
                        {
                            quadradosTesteControle.FillRectangle(cor_laranja, quadrado5);
                            botaoLaranja = true;
                        }
                    }   
                }
                return;
            }
        }

        private void joystickOperate()
        {
            MessageBox.Show("Entrando em fase de funcionamento");
            Process[] ps = Process.GetProcessesByName("Clone Hero");
            Process cloneHeroProcess = ps.FirstOrDefault();
            if (cloneHeroProcess != null)
            {
                IntPtr h = cloneHeroProcess.MainWindowHandle;
                SetForegroundWindow(h);
                InputSimulator isim = new InputSimulator();
                while (true)
                {
                    controle.Poll();
                    var data = controle.GetBufferedData();
                    foreach (var state in data)
                    {
                        if (state.Offset.ToString().Contains("Buttons0"))
                        {
                            //A
                            while(state.Offset.ToString().Contains("Value: 128"))
                            {
                                isim.Keyboard.KeyDown(VirtualKeyCode.VK_A);
                            }
                            isim.Keyboard.KeyUp(VirtualKeyCode.VK_A);
                            
                        }
                        if (state.Offset.ToString().Contains("Buttons1"))
                        {
                            //S
                            while (state.Offset.ToString().Contains("Value: 128"))
                            {
                                isim.Keyboard.KeyDown(VirtualKeyCode.VK_S);
                            }
                            isim.Keyboard.KeyUp(VirtualKeyCode.VK_S);
                        }
                        if (state.Offset.ToString().Contains("Buttons2"))
                        {
                            //J
                            while (state.Offset.ToString().Contains("Value: 128"))
                            {
                                isim.Keyboard.KeyDown(VirtualKeyCode.VK_J);
                            }
                            isim.Keyboard.KeyUp(VirtualKeyCode.VK_J);
                        }
                        if (state.Offset.ToString().Contains("Buttons3"))
                        {
                            //K
                            while (state.Offset.ToString().Contains("Value: 128"))
                            {
                                isim.Keyboard.KeyDown(VirtualKeyCode.VK_K);
                            }
                            isim.Keyboard.KeyUp(VirtualKeyCode.VK_K);
                        }
                        if (state.Offset.ToString().Contains("Buttons5"))
                        {
                            //L
                            while (state.Offset.ToString().Contains("Value: 128"))
                            {
                                isim.Keyboard.KeyDown(VirtualKeyCode.VK_L);
                            }
                            isim.Keyboard.KeyUp(VirtualKeyCode.VK_L);
                        }
                    }
                }
            }
        }
    }
}