﻿namespace ProjetoInterface
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.canvas = new System.Windows.Forms.Panel();
            this.conectouControle = new System.Windows.Forms.Label();
            this.botaoConectarControle = new System.Windows.Forms.Button();
            this.naoConectou = new System.Windows.Forms.Label();
            this.textoTestadorBotoes = new System.Windows.Forms.Label();
            this.canvas.SuspendLayout();
            this.SuspendLayout();
            // 
            // canvas
            // 
            this.canvas.Controls.Add(this.conectouControle);
            this.canvas.Controls.Add(this.botaoConectarControle);
            this.canvas.Controls.Add(this.naoConectou);
            this.canvas.Controls.Add(this.textoTestadorBotoes);
            this.canvas.Location = new System.Drawing.Point(12, 12);
            this.canvas.Name = "canvas";
            this.canvas.Size = new System.Drawing.Size(776, 426);
            this.canvas.TabIndex = 0;
            // 
            // conectouControle
            // 
            this.conectouControle.AutoSize = true;
            this.conectouControle.BackColor = System.Drawing.Color.Transparent;
            this.conectouControle.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.conectouControle.ForeColor = System.Drawing.Color.Green;
            this.conectouControle.Location = new System.Drawing.Point(286, 23);
            this.conectouControle.Name = "conectouControle";
            this.conectouControle.Size = new System.Drawing.Size(197, 25);
            this.conectouControle.TabIndex = 3;
            this.conectouControle.Text = "Controle Conectado!";
            this.conectouControle.Visible = false;
            // 
            // botaoConectarControle
            // 
            this.botaoConectarControle.Location = new System.Drawing.Point(537, 23);
            this.botaoConectarControle.Name = "botaoConectarControle";
            this.botaoConectarControle.Size = new System.Drawing.Size(159, 24);
            this.botaoConectarControle.TabIndex = 2;
            this.botaoConectarControle.Text = "Conectar Controle";
            this.botaoConectarControle.UseVisualStyleBackColor = true;
            this.botaoConectarControle.Click += new System.EventHandler(this.click_conectarControle);
            // 
            // naoConectou
            // 
            this.naoConectou.AutoSize = true;
            this.naoConectou.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.naoConectou.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.naoConectou.Location = new System.Drawing.Point(270, 23);
            this.naoConectou.Name = "naoConectou";
            this.naoConectou.Size = new System.Drawing.Size(222, 21);
            this.naoConectou.TabIndex = 1;
            this.naoConectou.Text = "Controle ainda não conectado!";
            // 
            // textoTestadorBotoes
            // 
            this.textoTestadorBotoes.Location = new System.Drawing.Point(0, 0);
            this.textoTestadorBotoes.Name = "textoTestadorBotoes";
            this.textoTestadorBotoes.Size = new System.Drawing.Size(100, 23);
            this.textoTestadorBotoes.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.canvas);
            this.Name = "Form1";
            this.Text = "Form1";
            this.canvas.ResumeLayout(false);
            this.canvas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel canvas;
        private Label textoTestadorBotoes;
        private Label naoConectou;
        private Button botaoConectarControle;
        private Label conectouControle;
    }
}